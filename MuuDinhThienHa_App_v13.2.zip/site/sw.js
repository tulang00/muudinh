// Service worker: lưu toàn bộ app để dùng offline.
// Trang chính: ưu tiên bản mới trên mạng, mất mạng mới dùng bản đã lưu. File nặng (bộ đọc chữ, font): dùng bản đã lưu.
const CACHE="muudinh-v13.2-9c45b5e753";
const FILES=["./", "fonts/be-vietnam-pro-latin-400-normal.woff2", "fonts/be-vietnam-pro-latin-500-normal.woff2", "fonts/be-vietnam-pro-latin-600-normal.woff2", "fonts/be-vietnam-pro-latin-700-normal.woff2", "fonts/be-vietnam-pro-vietnamese-400-normal.woff2", "fonts/be-vietnam-pro-vietnamese-500-normal.woff2", "fonts/be-vietnam-pro-vietnamese-600-normal.woff2", "fonts/be-vietnam-pro-vietnamese-700-normal.woff2", "fonts/fonts.css", "fonts/noto-serif-latin-600-normal.woff2", "fonts/noto-serif-latin-700-normal.woff2", "fonts/noto-serif-vietnamese-600-normal.woff2", "fonts/noto-serif-vietnamese-700-normal.woff2", "icons/apple-touch-icon.png", "icons/favicon-48.png", "icons/icon-192.png", "icons/icon-512.png", "icons/maskable-512.png", "index.html", "manifest.webmanifest", "ocr/eng.traineddata.gz", "ocr/tesseract-core-lstm.wasm.js", "ocr/tesseract-core-simd-lstm.wasm.js", "ocr/tesseract.min.js", "ocr/worker.min.js"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES.map(u=>new Request(u,{cache:"reload"})))).then(()=>self.skipWaiting()));});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET")return;
  const u=new URL(e.request.url);if(u.origin!==location.origin)return;
  const page=e.request.mode==="navigate"||/\/(index\.html)?$/.test(u.pathname);
  if(page){e.respondWith(fetch(e.request,{cache:"no-store"}).then(r=>{if(r.ok){const c=r.clone();caches.open(CACHE).then(x=>x.put("./",c));}return r;})
    .catch(()=>caches.match("./").then(r=>r||caches.match("index.html"))));return;}
  e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(r=>r||fetch(e.request)));
});
