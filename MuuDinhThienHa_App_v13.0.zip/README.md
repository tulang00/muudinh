# Mưu Định Thiên Hạ – App phối đội (v13.0)

Công cụ phối đội cho 三國：謀定天下: chọn hoặc chụp ảnh tướng và chiến pháp, tool xếp Đội 1 mạnh nhất rồi lắp các đội sau từ phần còn dư. Chạy hoàn toàn offline sau lần mở đầu tiên. Không tự ghi nhớ: mỗi lần mở là trang trắng.

Bộ file này cho ra **2 dạng app** từ cùng một mã nguồn:

| Dạng | Dùng cho | Cách cài |
|---|---|---|
| Web app (cài lên màn hình chính) | iPhone và Android | Mở link web → thêm vào màn hình chính |
| File APK | Android | Tải file `.apk` → cài |

## Cách đưa lên GitHub (làm 1 lần, khoảng 10 phút)

1. **Tạo tài khoản** tại github.com (nếu chưa có).
2. **Tạo kho mới:** bấm **+ → New repository**, đặt tên (ví dụ `muudinh`), chọn **Public**, bấm **Create repository**.
3. **Tải file lên:** ở trang kho vừa tạo, bấm **uploading an existing file**. Giải nén file zip này, rồi kéo **toàn bộ nội dung bên trong** (gồm cả thư mục `.github`, `site`, `android-res`, `keystore` và các file lẻ) vào trang. Bấm **Commit changes**.
4. **Bật trang web:** vào **Settings → Pages**, mục **Source** chọn **GitHub Actions**.
5. **Chạy build:** vào tab **Actions → Đăng web và build APK → Run workflow**. Chờ khoảng 5–8 phút cho đến khi cả 2 bước có dấu tích xanh.

## Cài lên điện thoại

**Link web** có dạng `https://<tên-tài-khoản>.github.io/<tên-kho>/`.

- **iPhone (Safari):** mở link → nút Chia sẻ → **Thêm vào MH chính**.
- **Android (Chrome):** mở link → menu ⋮ → **Cài đặt ứng dụng** (hoặc "Thêm vào màn hình chính").
- **Android, dùng file APK:** vào trang kho → mục **Releases** bên phải → **app-latest** → bấm **MuuDinhThienHa.apk** để tải → mở file → cho phép "Cài ứng dụng không rõ nguồn gốc" khi máy hỏi.

## Cập nhật bản mới

Thay file trong thư mục `site` (hoặc tải lên bộ file mới) rồi Commit. GitHub tự build lại cả web lẫn APK.
- Web app tự cập nhật ở lần mở sau khi có mạng.
- File APK mới cài đè lên bản cũ được, vì các bản dùng chung một khóa ký trong thư mục `keystore`.

## Ghi chú

- Kho để **Public** thì ai có link cũng xem được tool (tool không chứa dữ liệu cá nhân). GitHub Pages miễn phí yêu cầu kho Public.
- File APK là bản tự ký để cài trực tiếp, không phải bản phát hành trên CH Play. Khóa ký trong thư mục `keystore` là khóa thử nghiệm dùng chung, chỉ phù hợp để cài nội bộ.
- Tính năng nhận từ ảnh chạy ngay trên máy, ảnh không gửi đi đâu. Nên dùng ảnh chụp màn hình gốc.
